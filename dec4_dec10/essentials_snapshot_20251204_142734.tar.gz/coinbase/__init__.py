"""Coinbase package marker"""
